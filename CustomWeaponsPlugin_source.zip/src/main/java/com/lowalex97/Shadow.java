package com.lowalex97;

public class Shadow {


    public Shadow() {
    }


    @Override
    public String toString() {
        return "Shadow";
    }
}
