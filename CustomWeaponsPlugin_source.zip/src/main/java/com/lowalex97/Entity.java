package com.lowalex97;

public class Entity {


    public Entity() {
    }


    @Override
    public String toString() {
        return "Entity";
    }
}
