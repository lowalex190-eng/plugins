package com.lowalex97;

public class XMLSchema {


    public XMLSchema() {
    }


    @Override
    public String toString() {
        return "XMLSchema";
    }
}
