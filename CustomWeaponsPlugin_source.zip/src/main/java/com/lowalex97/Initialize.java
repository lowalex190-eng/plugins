package com.lowalex97;

public class Initialize {


    public Initialize() {
    }


    @Override
    public String toString() {
        return "Initialize";
    }
}
