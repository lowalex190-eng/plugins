package com.lowalex97;

public class Create {


    public Create() {
    }


    @Override
    public String toString() {
        return "Create";
    }
}
