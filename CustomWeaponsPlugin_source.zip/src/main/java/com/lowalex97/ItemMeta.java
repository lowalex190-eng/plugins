package com.lowalex97;

public class ItemMeta {


    public ItemMeta() {
    }


    @Override
    public String toString() {
        return "ItemMeta";
    }
}
