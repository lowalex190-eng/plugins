package com.lowalex97;

import org.bukkit.plugin.java.JavaPlugin;

public
class CustomWeaponsPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        // Initialize managers
        CustomItemManager itemManager = new CustomItemManager(this);
        CraftingManager craftingManager = new CraftingManager(this, itemManager);

        // Register events
        getServer().getPluginManager().registerEvents(new WeaponListener(this, itemManager), this);

        getLogger().info("CustomWeaponsPlugin has been enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("CustomWeaponsPlugin has been disabled!");
    }
}
