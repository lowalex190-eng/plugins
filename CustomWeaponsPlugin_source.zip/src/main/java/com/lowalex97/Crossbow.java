package com.lowalex97;

public class Crossbow {


    public Crossbow() {
    }


    @Override
    public String toString() {
        return "Crossbow";
    }
}
