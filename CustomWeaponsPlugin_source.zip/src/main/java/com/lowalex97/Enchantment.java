package com.lowalex97;

public class Enchantment {


    public Enchantment() {
    }


    @Override
    public String toString() {
        return "Enchantment";
    }
}
