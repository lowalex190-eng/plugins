package com.lowalex97;

public class Deal {


    public Deal() {
    }


    @Override
    public String toString() {
        return "Deal";
    }
}
