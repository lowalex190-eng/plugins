package com.lowalex97;

public class Register {


    public Register() {
    }


    @Override
    public String toString() {
        return "Register";
    }
}
