package com.lowalex97;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public
class ShadowBlade {
    private final CustomWeaponsPlugin plugin;
    private final CustomItemManager itemManager;
    private final Map<UUID, Long> cooldowns;
    private final Map<UUID, Integer> blinkCounts;

    public ShadowBlade(CustomWeaponsPlugin plugin, CustomItemManager itemManager) {
        this.plugin = plugin;
        this.itemManager = itemManager;
        this.cooldowns = new HashMap<>();
        this.blinkCounts = new HashMap<>();
    }

    public void handleRightClick(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        if (!itemManager.isCustomItem(item, "shadow_blade")) return;

        if (player.isSneaking()) {
            UUID playerId = player.getUniqueId();
            long currentTime = System.currentTimeMillis();

            if (cooldowns.containsKey(playerId) && currentTime - cooldowns.get(playerId) < 20000) {
                long remaining = (20000 - (currentTime - cooldowns.get(playerId))) / 1000;
                player.sendMessage("§cAbility on cooldown! " + remaining + " seconds remaining.");
                return;
            }

            if (!blinkCounts.containsKey(playerId)) {
                blinkCounts.put(playerId, 3);
            }

            if (blinkCounts.get(playerId) <= 0) {
                player.sendMessage("§cNo blinks remaining!");
                return;
            }

            blink(player);
            blinkCounts.put(playerId, blinkCounts.get(playerId) - 1);

            if (blinkCounts.get(playerId) <= 0) {
                cooldowns.put(playerId, currentTime);
            }
        }
    }

    private void blink(Player player) {
        Location targetLocation = player.getTargetBlock(null, 8).getLocation();
        if (targetLocation.getBlock().getType() != Material.AIR) {
            targetLocation.add(0, 1, 0);
        }

        // Check for entities in the target location
        for (Entity entity : player.getWorld().getNearbyEntities(targetLocation, 1, 1, 1)) {
            if (entity instanceof LivingEntity && entity != player) {
                // Deal damage if not blocking with shield
                if (!(entity instanceof Player) || !((Player) entity).isBlocking()) {
                    ((LivingEntity) entity).damage(4); // 2 hearts of damage
                }
            }
        }

        player.teleport(targetLocation);
        player.getWorld().playSound(player.getLocation(), "entity.enderman.teleport", 1.0f, 1.0f);
    }

    public void handleKill(Player killer, LivingEntity victim) {
        if (killer == null) return;
        ItemStack item = killer.getInventory().getItemInMainHand();
        if (itemManager.isCustomItem(item, "shadow_blade")) {
            itemManager.increaseKillCount(item);
        }
    }
}
