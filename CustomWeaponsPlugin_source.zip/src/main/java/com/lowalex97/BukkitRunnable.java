package com.lowalex97;

public class BukkitRunnable {


    public BukkitRunnable() {
    }


    @Override
    public String toString() {
        return "BukkitRunnable";
    }
}
