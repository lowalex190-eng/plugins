package com.lowalex97;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;

public
class CraftingManager {
    private final CustomWeaponsPlugin plugin;
    private final CustomItemManager itemManager;

    public CraftingManager(CustomWeaponsPlugin plugin, CustomItemManager itemManager) {
        this.plugin = plugin;
        this.itemManager = itemManager;
        registerRecipes();
    }

    private void registerRecipes() {
        // Hell Fire Crossbow recipe
        NamespacedKey crossbowKey = new NamespacedKey(plugin, "hell_fire_crossbow");
        ShapedRecipe crossbowRecipe = new ShapedRecipe(crossbowKey, itemManager.getCustomItem("hell_fire_crossbow"));
        crossbowRecipe.shape("BNB", "N N", "BNB");
        crossbowRecipe.setIngredient('B', Material.BLAZE_ROD);
        crossbowRecipe.setIngredient('N', Material.NETHERITE_INGOT);
        Bukkit.addRecipe(crossbowRecipe);

        // Shadow Blade recipe
        NamespacedKey swordKey = new NamespacedKey(plugin, "shadow_blade");
        ShapedRecipe swordRecipe = new ShapedRecipe(swordKey, itemManager.getCustomItem("shadow_blade"));
        swordRecipe.shape("D D", "D D", "DED");
        swordRecipe.setIngredient('D', Material.DIAMOND);
        swordRecipe.setIngredient('E', Material.ECHO_SHARD);
        Bukkit.addRecipe(swordRecipe);
    }
}
