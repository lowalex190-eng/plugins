package com.lowalex97;

import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public
class WeaponListener implements Listener {
    private final CustomWeaponsPlugin plugin;
    private final CustomItemManager itemManager;
    private final HellFireCrossbow hellFireCrossbow;
    private final ShadowBlade shadowBlade;

    public WeaponListener(CustomWeaponsPlugin plugin, CustomItemManager itemManager) {
        this.plugin = plugin;
        this.itemManager = itemManager;
        this.hellFireCrossbow = new HellFireCrossbow(plugin, itemManager);
        this.shadowBlade = new ShadowBlade(plugin, itemManager);
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        hellFireCrossbow.handleRightClick(event);
        shadowBlade.handleRightClick(event);
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player && event.getEntity() instanceof LivingEntity) {
            shadowBlade.handleKill((Player) event.getDamager(), (LivingEntity) event.getEntity());
        }
    }
}
