package com.lowalex97;

public class Hell {


    public Hell() {
    }


    @Override
    public String toString() {
        return "Hell";
    }
}
