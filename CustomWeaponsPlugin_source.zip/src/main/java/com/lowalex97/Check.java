package com.lowalex97;

public class Check {


    public Check() {
    }


    @Override
    public String toString() {
        return "Check";
    }
}
