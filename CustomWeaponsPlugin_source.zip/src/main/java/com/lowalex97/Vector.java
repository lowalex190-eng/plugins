package com.lowalex97;

public class Vector {


    public Vector() {
    }


    @Override
    public String toString() {
        return "Vector";
    }
}
