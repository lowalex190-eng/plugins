package com.lowalex97;

public class EntityDamageByEntityEvent {


    public EntityDamageByEntityEvent() {
    }


    @Override
    public String toString() {
        return "EntityDamageByEntityEvent";
    }
}
