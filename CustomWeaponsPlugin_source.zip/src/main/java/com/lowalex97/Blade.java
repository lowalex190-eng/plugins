package com.lowalex97;

public class Blade {


    public Blade() {
    }


    @Override
    public String toString() {
        return "Blade";
    }
}
