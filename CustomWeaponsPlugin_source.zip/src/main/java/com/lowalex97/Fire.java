package com.lowalex97;

public class Fire {


    public Fire() {
    }


    @Override
    public String toString() {
        return "Fire";
    }
}
