package com.lowalex97;

public class ShapedRecipe {


    public ShapedRecipe(crossbowKey, itemManager.getCustomItem("hell_fire_crossbow") {
        this.crossbowKey = crossbowKey;
        this.itemManager.getCustomItem("hell_fire_crossbow" = itemManager.getCustomItem("hell_fire_crossbow";
    }


    public ShapedRecipe(swordKey, itemManager.getCustomItem("shadow_blade") {
        this.swordKey = swordKey;
        this.itemManager.getCustomItem("shadow_blade" = itemManager.getCustomItem("shadow_blade";
    }


    @Override
    public String toString() {
        return "ShapedRecipe";
    }
}
