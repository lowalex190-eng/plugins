package com.lowalex97;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import java.util.HashMap;
import java.util.Map;

public
class CustomItemManager {
    private final CustomWeaponsPlugin plugin;
    private final Map<String, ItemStack> customItems;
    private final NamespacedKey weaponKey;
    private final NamespacedKey killCountKey;

    public CustomItemManager(CustomWeaponsPlugin plugin) {
        this.plugin = plugin;
        this.customItems = new HashMap<>();
        this.weaponKey = new NamespacedKey(plugin, "custom_weapon");
        this.killCountKey = new NamespacedKey(plugin, "kill_count");

        createCustomItems();
    }

    private void createCustomItems() {
        // Create Hell Fire Crossbow
        ItemStack hellFireCrossbow = new ItemStack(Material.CROSSBOW);
        ItemMeta crossbowMeta = hellFireCrossbow.getItemMeta();
        crossbowMeta.setDisplayName("§6Hell Fire Crossbow");
        crossbowMeta.getPersistentDataContainer().set(weaponKey, PersistentDataType.STRING, "hell_fire_crossbow");
        hellFireCrossbow.setItemMeta(crossbowMeta);
        customItems.put("hell_fire_crossbow", hellFireCrossbow);

        // Create Shadow Blade
        ItemStack shadowBlade = new ItemStack(Material.IRON_SWORD);
        ItemMeta swordMeta = shadowBlade.getItemMeta();
        swordMeta.setDisplayName("§5Shadow Blade");
        swordMeta.getPersistentDataContainer().set(weaponKey, PersistentDataType.STRING, "shadow_blade");
        swordMeta.getPersistentDataContainer().set(killCountKey, PersistentDataType.INTEGER, 0);
        shadowBlade.setItemMeta(swordMeta);
        customItems.put("shadow_blade", shadowBlade);
    }

    public ItemStack getCustomItem(String name) {
        return customItems.get(name).clone();
    }

    public boolean isCustomItem(ItemStack item, String name) {
        if (item == null || !item.hasItemMeta()) return false;
        String weaponType = item.getItemMeta().getPersistentDataContainer().get(weaponKey, PersistentDataType.STRING);
        return name.equals(weaponType);
    }

    public void increaseKillCount(ItemStack item) {
        if (!item.hasItemMeta()) return;
        ItemMeta meta = item.getItemMeta();
        int kills = meta.getPersistentDataContainer().getOrDefault(killCountKey, PersistentDataType.INTEGER, 0);
        if (kills < 8) {
            kills++;
            meta.getPersistentDataContainer().set(killCountKey, PersistentDataType.INTEGER, kills);
            meta.addEnchant(Enchantment.DAMAGE_ALL, kills, true);
            item.setItemMeta(meta);
        }
    }

    public int getKillCount(ItemStack item) {
        if (!item.hasItemMeta()) return 0;
        return item.getItemMeta().getPersistentDataContainer().getOrDefault(killCountKey, PersistentDataType.INTEGER, 0);
    }
}
