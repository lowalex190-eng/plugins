package com.lowalex97;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public
class HellFireCrossbow {
    private final CustomWeaponsPlugin plugin;
    private final CustomItemManager itemManager;
    private final Map<UUID, Long> cooldowns;

    public HellFireCrossbow(CustomWeaponsPlugin plugin, CustomItemManager itemManager) {
        this.plugin = plugin;
        this.itemManager = itemManager;
        this.cooldowns = new HashMap<>();
    }

    public void handleRightClick(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        if (!itemManager.isCustomItem(item, "hell_fire_crossbow")) return;

        if (player.isSneaking()) {
            UUID playerId = player.getUniqueId();
            long currentTime = System.currentTimeMillis();

            if (cooldowns.containsKey(playerId) && currentTime - cooldowns.get(playerId) < 20000) {
                long remaining = (20000 - (currentTime - cooldowns.get(playerId))) / 1000;
                player.sendMessage("§cAbility on cooldown! " + remaining + " seconds remaining.");
                return;
            }

            cooldowns.put(playerId, currentTime);
            shootFireball(player);
        }
    }

    private void shootFireball(Player player) {
        Location eyeLocation = player.getEyeLocation();
        Fireball fireball = player.getWorld().spawn(eyeLocation.add(eyeLocation.getDirection().multiply(2)), Fireball.class);
        fireball.setShooter(player);
        fireball.setYield(0);
        fireball.setIsIncendiary(false);
        fireball.setVelocity(eyeLocation.getDirection().multiply(1.5));

        new BukkitRunnable() {
            @Override
            public void run() {
                if (fireball.isDead()) return;
                fireball.getWorld().createExplosion(fireball.getLocation(), 0, false, false);
                fireball.remove();
            }
        }.runTaskLater(plugin, 40);
    }
}
